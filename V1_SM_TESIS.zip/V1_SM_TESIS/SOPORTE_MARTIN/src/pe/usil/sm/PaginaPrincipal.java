/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.usil.sm;

import pe.usil.sm.view.LoginView;

/**
 *
 * @author fredy
 */
public class PaginaPrincipal {
      public static void main(String[] args) {
          LoginView.main(null);
  }
}
