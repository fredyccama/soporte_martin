/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.usil.sm.util;

import java.awt.Component;
import javax.swing.JOptionPane;

/**
 *
 * @author fredy
 */
public final class Mensaje {

    private Mensaje() {
    }

    public static void showInfo(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "INFO",
                JOptionPane.INFORMATION_MESSAGE);
    }

    public static void showError(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "ERROR",
                JOptionPane.ERROR_MESSAGE);
    }

    public static boolean showConfirm(Component parent, String message) {
        int rpta = JOptionPane.showConfirmDialog(parent, message, "CONFIRMAR",
                JOptionPane.YES_NO_OPTION);
        return (rpta == JOptionPane.YES_OPTION);
    }
}
