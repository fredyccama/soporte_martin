/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.usil.sm.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import pe.usil.sm.dao.espec.PersonaDaoEspec;
import pe.usil.sm.db.AccesoDB;
import pe.usil.sm.model.PersonaModel;

/**
 *
 * @author fredy
 */
public class PersonaDaoImpl implements PersonaDaoEspec {

    private final String SQL_SELECT = "select p.idpersona,p.idtpersona,p.apellidos,"
            + "p.nombre,p.dni,p.telefono,p.direccion,u.idrol,u.usuario "
            + "from persona p "
            + "join usuario u on p.idpersona = u.idpersona "
            + "where p.idpersona in (select idpersona "
            + "from usuario ";
    private final String SQL_INSERT="insert into persona(idpersona, idtpersona, apellidos, nombre,"
                    +" dni, telefono, direccion, usuario, clave) "
            +"values (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    public PersonaModel validar(String usuario, String clave) {
        PersonaModel bean = null;
        Connection cn = null;
        try {
            cn = AccesoDB.getConnection();
            

            String sql = SQL_SELECT + "where usuario = ? and clave = SHA(?) "
                    + "and estado = 1)";
            PreparedStatement pstm = cn.prepareStatement(sql);
            pstm.setString(1, usuario);
            pstm.setString(2, clave);
            ResultSet rs = pstm.executeQuery();
            if (rs.next()) {
                bean = mapRow(rs);
            }
            rs.close();
            pstm.close();
        } catch (SQLException e) {
            throw new RuntimeException(e.getMessage());
        } catch (Exception e) {
            String msg = "Error en el proceso de validación.";
            if (e.getMessage() != null) {
                msg += "\n" + e.getMessage();
            }
            throw new RuntimeException(msg);
        } finally {
            try {
                cn.close();
            } catch (Exception e) {
            }
        }
        return bean;
    }

    @Override
    public List<PersonaModel> taerLista(PersonaModel bean) {
        List<PersonaModel> lista = new ArrayList<>();
        Connection cn = null;
        try {
            cn = AccesoDB.getConnection();
            
            String sql =  " select idpersona, idtpersona, apellidos, nombre,"
                    +" dni, telefono, direccion, usuario from persona "
                    +"where  upper(nombre) like concat(?,'%') and idpersona=2 ";
            PreparedStatement pstm = cn.prepareStatement(sql);
            pstm.setString(1, bean.getNombre().toUpperCase());
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                PersonaModel model = mapRow(rs);
                lista.add(model);
            }
            rs.close();
            pstm.close();
        } catch (SQLException e) {
            throw new RuntimeException(e.getMessage());
        } catch (Exception e) {
            String msg = "Error en el proceso. ";
            if (e.getMessage() != null) {
                msg += "\n" + e.getMessage();
            }
            throw new RuntimeException(msg);
        } finally {
            try {
                cn.close();
            } catch (Exception e) {
            }
        }
        return lista;
    }

    @Override
    public void insertar(PersonaModel bean) {
Connection cn = null;
    try {
      // Obtener la conexión
      cn = AccesoDB.getConnection();
      // Habilitar la transacción
      cn.setAutoCommit(false);
      // Paso 1: Actualizar contador
      String sql =SQL_INSERT;
      PreparedStatement pstm = cn.prepareStatement(sql);     
      // Paso 4: Registrar empleado
      pstm = cn.prepareStatement(SQL_INSERT);
      pstm.setInt(1, bean.getIdpersona());
      pstm.setInt(2, bean.getIdtpersona());
      pstm.setString(3, bean.getApellidos());
      pstm.setString(4, bean.getNombre());
      pstm.setString(5, bean.getDni());
      pstm.setString(6, bean.getDireccion());
      pstm.setString(7, bean.getUsuario());
      pstm.setString(8, bean.getClave());
      pstm.executeUpdate();
      pstm.close();
      cn.commit();
    } catch (Exception e) {
      try {
        cn.rollback();
      } catch (Exception e1) {
      }
      String msg = "Error en el proceso insertar empleado.";
      if (e.getMessage() != null) {
        msg += "\n" + e.getMessage();
      }
      throw new RuntimeException(msg);
    } finally {
      try {
        cn.close();
      } catch (Exception e) {
      }
    }
    }

    @Override
    public void actualizar(PersonaModel bean) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void eliminar(String codigo) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public PersonaModel mapRow(ResultSet rs) throws SQLException {
        PersonaModel bean = new PersonaModel();
        bean.setIdpersona(rs.getInt("idpersona"));
        bean.setIdtpersona(rs.getInt("idtpersona"));
        bean.setApellidos(rs.getString("apellidos"));
        bean.setNombre(rs.getString("nombre"));
        bean.setDni(rs.getString("dni"));
        bean.setTelefono(rs.getString("telefono"));
        bean.setDireccion(rs.getString("direccion"));
        bean.setUsuario(rs.getString("usuario"));
        bean.setClave("**************");
        return bean;
    }

}
