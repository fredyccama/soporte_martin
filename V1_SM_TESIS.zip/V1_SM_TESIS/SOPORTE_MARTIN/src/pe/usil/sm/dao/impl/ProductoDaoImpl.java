/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.usil.sm.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import pe.usil.sm.dao.espec.PersonaDaoEspec;
import pe.usil.sm.dao.espec.ProductoDaoEspc;
import pe.usil.sm.db.AccesoDB;
import pe.usil.sm.model.PersonaModel;
import pe.usil.sm.model.ProductoModel;

/**
 *
 * @author fredy
 */
public class ProductoDaoImpl implements ProductoDaoEspc {

    public final String SQL_SELECT = "selec idproducto, idtproducto, costo, marca, modelo, descripcion, estado from producto";

    @Override
    public List<ProductoModel> taerLista(ProductoModel bean) {
       List<ProductoModel> lista = new ArrayList<>();
        Connection cn = null;
        try {
            cn = AccesoDB.getConnection();
            String sql = SQL_SELECT
                    + " where idproducto like concat(?,'%') ";
            PreparedStatement pstm = cn.prepareStatement(sql);
            pstm.setInt(1, bean.getIdproducto());
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                ProductoModel model = (ProductoModel) mapRow(rs);
                lista.add(model);
            }
            rs.close();
            pstm.close();
        } catch (SQLException e) {
            throw new RuntimeException(e.getMessage());
        } catch (Exception e) {
            String msg = "Error en el proceso. ";
            if (e.getMessage() != null) {
                msg += "\n" + e.getMessage();
            }
            throw new RuntimeException(msg);
        } finally {
            try {
                cn.close();
            } catch (Exception e) {
            }
        }
        return lista;
    }

    @Override
    public void insertar(ProductoModel bean) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void actualizar(ProductoModel bean) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void eliminar(String codigo) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public PersonaDaoEspec mapRow(ResultSet rs) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
