/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.usil.sm.dao.espec;

import java.util.List;
import pe.usil.sm.model.ProductoModel;

/**
 *
 * @author fredy
 */
public interface ProductoDaoEspc extends CrudDaoEspec<ProductoModel>, RowMapper<PersonaDaoEspec>{

}
