/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.usil.sm.dao.espec;

import pe.usil.sm.model.PersonaModel;

/**
 *
 * @author fredy
 */
public interface PersonaDaoEspec extends CrudDaoEspec<PersonaModel>, RowMapper<PersonaModel>{
    PersonaModel validar(String usuario, String clave);
}
