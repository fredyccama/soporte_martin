/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.usil.sm.service;

import pe.usil.sm.dao.espec.PersonaDaoEspec;
import pe.usil.sm.dao.impl.PersonaDaoImpl;
import pe.usil.sm.model.PersonaModel;

/**
 *
 * @author fredy
 */
public class LoginService {

    public PersonaModel validar(String usuario, String clave) {

        if (usuario == null || usuario.isEmpty()) {
            throw new RuntimeException("Error, faltan datos.");
        }
        if (clave == null || clave.isEmpty()) {
            throw new RuntimeException("Error, faltan datos.");
        }

        PersonaDaoEspec personaDao;
        personaDao = new PersonaDaoImpl();
        PersonaModel bean = personaDao.validar(usuario, clave);
        if (bean == null) {
            throw new RuntimeException("Error, datos incorrctos.");
        }
        return bean;
    }

}
