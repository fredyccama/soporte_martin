/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.usil.sm.service;

import java.util.List;
import pe.usil.sm.dao.espec.PersonaDaoEspec;
import pe.usil.sm.dao.impl.PersonaDaoImpl;
import pe.usil.sm.model.PersonaModel;

/**
 *
 * @author fredy
 */
public class PersonaService {

    private PersonaDaoEspec personaDaoEspec;
    

    public PersonaService() {
        personaDaoEspec = new PersonaDaoImpl();
    }
      public List<PersonaModel> traerEmpleados(PersonaModel bean) {
    return personaDaoEspec.taerLista(bean);
  }
}
