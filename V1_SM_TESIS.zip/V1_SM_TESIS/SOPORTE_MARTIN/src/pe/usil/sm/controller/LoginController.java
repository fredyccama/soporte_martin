/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.usil.sm.controller;

import pe.usil.sm.model.PersonaModel;
import pe.usil.sm.service.LoginService;
import pe.usil.sm.util.Session;

/**
 *
 * @author fredy
 */
public class LoginController {

    public void validar(String usuario, String clave) {
        LoginService loginService;
        loginService = new LoginService();
        PersonaModel bean = loginService.validar(usuario, clave);
        Session.put("usuario", bean);
    }
}
