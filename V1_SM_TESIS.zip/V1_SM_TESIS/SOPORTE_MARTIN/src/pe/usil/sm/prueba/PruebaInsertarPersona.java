/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.usil.sm.prueba;

import pe.usil.sm.dao.espec.PersonaDaoEspec;
import pe.usil.sm.dao.impl.PersonaDaoImpl;
import pe.usil.sm.model.PersonaModel;
import pe.usil.sm.util.Mensaje;

/**
 *
 * @author FIREFOX_USR
 */
public class PruebaInsertarPersona {

    public static void main(String[] args) {
        PersonaModel bean = new PersonaModel();
        try {
            bean.setIdpersona(1);
            bean.setIdtpersona(2);
            bean.setApellidos("ccama");
            bean.setNombre("fredy");
            bean.setDni("70780371");
            bean.setTelefono("9999999");
            bean.setDireccion("los aliasd");
            bean.setUsuario("fccama");
            bean.setClave("123");

            PersonaDaoEspec personaDaoEspec = new PersonaDaoImpl();
            personaDaoEspec.insertar(bean);

            System.out.println("Todo ok. Codigo: " + bean.getIdpersona());
        } catch (Exception e) {
        Mensaje.showError(null, e.getMessage());
            System.out.println("alv");
        }
    }

}
