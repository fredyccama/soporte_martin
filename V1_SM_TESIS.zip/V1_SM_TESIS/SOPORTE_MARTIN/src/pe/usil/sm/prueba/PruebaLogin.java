/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.usil.sm.prueba;

import pe.usil.sm.model.PersonaModel;
import pe.usil.sm.service.LoginService;

/**
 *
 * @author fredy
 */
public class PruebaLogin {

    public static void main(String[] args) {
        try {
            LoginService service = new LoginService();
            PersonaModel bean = service.validar("far", "far");
            System.out.println("nombre:" + bean.getNombre());
            System.out.println("direccion:" + bean.getDireccion());
            System.out.println("dni: "+bean.getDni());
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }

    }
}
