/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.usil.sm.prueba;

import java.sql.SQLException;
import pe.usil.sm.db.AccesoDB;

/**
 *
 * @author fredy
 */
public class PruebaConnection {
    public static void main(String[] args) throws SQLException {
        AccesoDB db=null;
        System.out.println("db"+db.getConnection());
    }
}
