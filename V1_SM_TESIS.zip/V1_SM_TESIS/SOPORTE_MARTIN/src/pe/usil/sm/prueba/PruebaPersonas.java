/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.usil.sm.prueba;

import java.util.List;
import pe.usil.sm.controller.PersonaController;
import pe.usil.sm.model.PersonaModel;
import pe.usil.sm.util.Mensaje;

/**
 *
 * @author fredy
 */
public class PruebaPersonas {

    public static void main(String[] args) {
        try {
            // Datos
            PersonaModel model = new PersonaModel();
            model.setNombre("");

            // Data
            PersonaController control = new PersonaController();
            List<PersonaModel> lista = control.traerEmpleados(model);
            if (lista == null || lista.isEmpty()) {
                throw new Exception("No hay datos.");
            }
            System.out.println("Filas: " + lista.size());
        } catch (Exception e) {
            Mensaje.showError(null, e.getMessage());
            System.out.println("alv");
        }
    }
}
