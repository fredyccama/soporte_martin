/*
 * en este archivo accedemos a la base de datos que
    tenemos en mysql
 */
package pe.usil.sm.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author fredy ccama
 */
public final class AccesoDB {

    private AccesoDB() {
    }

    public final static Connection getConnection() throws SQLException {
        Connection cn = null;

        String driver = "com.mysql.jdbc.Driver";
        String urlDB = "jdbc:mysql://localhost/sist_inventario";
        String user = "root";
        String pass = "";
        try {
            Class.forName(driver).newInstance();
            cn=DriverManager.getConnection(urlDB,user,pass);
            System.out.println("exito man, hasta aqui vamos bien");
        } catch (ClassNotFoundException e) {
      throw new SQLException("No se ha encontrado el driver.");
    } catch (Exception e) {
      throw new SQLException("No se tiene acceso al servidor.");
    }    

    return cn;
    }
}
